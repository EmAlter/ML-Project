<?php
require_once('../../config.php');

global $DB, $CFG, $USER, $PAGE, $OUTPUT;

// Impostazioni della pagina Moodle
$PAGE->set_url(new moodle_url('/local/tokenlogin/index.php'));
$PAGE->set_context(context_system::instance());
$PAGE->set_title('Accesso al Test');
$PAGE->set_heading('Inserisci il tuo Token');

// 1. Recupero del token dal form (sanitizzato contro le injection)
$token = optional_param('usertoken', '', PARAM_ALPHANUMEXT);
$error_message = '';

if ($token) {
    $token = strtolower(trim($token)); // Pulisce spazi e rende case-insensitive

    // 2. Cerca l'utente nel database tramite lo username (che equivale al token)
    $user = $DB->get_record('user', array('username' => $token, 'deleted' => 0, 'suspended' => 0));

    if ($user) {
        // 3. Eccezione per il Progettista (Admin)
        // Impediamo che l'admin faccia login da qui per questioni di sicurezza
        if (is_siteadmin($user)) {
            redirect(new moodle_url('/login/index.php'), 'Gli amministratori devono usare il login standard.', null, \core\output\notification::NOTIFY_ERROR);
        }

        // 4. Autenticazione forzata per Testati e Moderatori
        complete_user_login($user);
        
        // Redirezione alla dashboard o al corso
        redirect(new moodle_url('/my/')); 
    } else {
        $error_message = 'Token non valido. Riprova.';
    }
}

// 5. Renderizzazione del frontend
echo $OUTPUT->header();

if ($error_message) {
    echo $OUTPUT->notification($error_message, 'error');
}
?>

<div style="max-width: 400px; margin: 50px auto; text-align: center;">
    <form action="index.php" method="POST">
        <label for="usertoken" style="font-size: 1.2rem; font-weight: bold;">Token Identificativo:</label><br><br>
        <input type="text" id="usertoken" name="usertoken" required autocomplete="off" 
               style="width: 100%; padding: 10px; font-size: 1.5rem; text-align: center; text-transform: uppercase;"><br><br>
        <button type="submit" class="btn btn-primary btn-lg">Accedi</button>
    </form>
    <br><br>
    <a href="<?php echo $CFG->wwwroot; ?>/login/index.php" style="font-size: 0.8rem; color: #888;">Accesso Progettista</a>
</div>

<?php
echo $OUTPUT->footer();
?>