<?php
defined('MOODLE_INTERNAL') || die();

/** @var stdClass $plugin */

$plugin->component = 'local_tokenlogin';
$plugin->version   = 2026070500; // Usa la data odierna
$plugin->requires  = 2022112800; // Versione minima di Moodle (es. 4.1+)
$plugin->maturity  = MATURITY_STABLE;